<?php header('Location: tableau.php'); ?>


