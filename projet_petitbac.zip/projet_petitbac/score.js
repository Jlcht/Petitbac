const toggleButton = document.querySelector('.toggle-button-score');
const toggleContent = document.querySelector('.toggle-content-score');

toggleButton.addEventListener('click', () => {
    toggleButton.classList.toggle('active');
    toggleContent.classList.toggle('active');
});

// Get all table cells
var cells = document.querySelectorAll('td');

// Loop through each cell
cells.forEach(function(cell) {
    // Check if the cell content is "0"
    if (cell.textContent === "0") {
        // Add the "red" class to the cell
        cell.classList.add('red');
    } else {
        // Add the "green" class to the cell
        cell.classList.add('green');
    }
});