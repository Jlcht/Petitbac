<?php
    session_start();

        try
        {
            $bdd = new PDO('mysql:host=localhost;dbname=petitbac', 'root', '');
        }
        catch (Exception $e)
        {
            die('Erreur : ' . $e->getMessage());
        }


    // Define the SQL query
    $sql = "INSERT INTO jeu (Celebrity, Country, City, Animal, Object, Colour, Brand) VALUES (:celebrity, :country, :city, :animal, :object, :colour, :brand)";

    // Prepare the statement
    $req = $bdd->prepare($sql);

    // Define the parameters
    $param = [
        'celebrity' => $_SESSION['celebrity'],
        'country' => $_SESSION['country'],
        'city' => $_SESSION['city'],
        'animal' => $_SESSION['animal'],
        'object' => $_SESSION['object'],
        'colour' => $_SESSION['color'],
        'brand' => $_SESSION['brand']
    ];

    // Execute the prepared statement
    $req->execute($param);

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Score</title>
</head>
<body>

<link rel="stylesheet" type="text/css" href="score.css">
<br><br>
<h1>Your score is : </h1>
<h2><?php echo htmlspecialchars($_SESSION['totalScore']) ; ?></h2>
<br><br>
<h3 class="chrono">Your chrono is : <?php echo htmlspecialchars($_SESSION['chronoStringValue']) ; ?></h3>
<button class="toggle-button-score">Details</button>
<div class="toggle-content-score">
    <table>
        <tr>
            <th>Celebrity</th>
            <td><?php echo htmlspecialchars($_SESSION['celebrity']); ?></td>
            <td><?php echo htmlspecialchars($_SESSION['Scelebrity']); ?></td>
        </tr>
        <tr>
            <th>Country</th>
            <td><?php echo htmlspecialchars($_SESSION['country']); ?></td>
            <td><?php echo htmlspecialchars($_SESSION['Scountry']); ?></td>
        </tr>
        <tr>
            <th>City</th>
            <td><?php echo htmlspecialchars($_SESSION['city']); ?></td>
            <td><?php echo htmlspecialchars($_SESSION['Scity']); ?></td>
        </tr>
        <tr>
            <th>Animal</th>
            <td><?php echo htmlspecialchars($_SESSION['animal']); ?></td>
            <td><?php echo htmlspecialchars($_SESSION['Sanimal']); ?></td>
        </tr>
        <tr>
            <th>Brand</th>
            <td><?php echo htmlspecialchars($_SESSION['brand']); ?></td>
            <td><?php echo htmlspecialchars($_SESSION['Sbrand']); ?></td>

        </tr>
        <tr>
            <th>Object</th>
            <td><?php echo htmlspecialchars($_SESSION['object']); ?></td>
            <td><?php echo htmlspecialchars($_SESSION['Sobject']); ?></td>
        </tr>
        <tr>
            <th>Colour</th>
            <td><?php echo htmlspecialchars($_SESSION['colour']); ?></td>
            <td><?php echo htmlspecialchars($_SESSION['Scolour']); ?></td>
        </tr>
    </table>

</div>
<script src="score.js"></script>
</body>
</html>

