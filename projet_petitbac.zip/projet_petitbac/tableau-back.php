<?php
session_start();
var_dump($_POST);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $_SESSION['celebrity'] = $_POST['celebrity'];
    $_SESSION['country'] = $_POST['country'];
    $_SESSION['city'] = $_POST['city'];
    $_SESSION['animal'] = $_POST['animal'];
    $_SESSION['brand'] = $_POST['brand'];
    $_SESSION['object'] = $_POST['object'];
    $_SESSION['colour'] = $_POST['colour'];
    var_dump($_SESSION);

    $_SESSION['Scelebrity']=0;
    $_SESSION['Scountry']=0;
    $_SESSION['Scity']=0;
    $_SESSION['Sanimal']=0;
    $_SESSION['Sbrand']=0;
    $_SESSION['Sobject']=0;
    $_SESSION['Scolour']=0;

    $_SESSION['totalScore'] = 0;

    $randomLetter = $_COOKIE['randomLetter'];
    $randomLetterLower = strtolower($randomLetter);
    $randomLetterUpper = strtoupper($randomLetter);

    $chronoValue = $_POST['chrono'];
    $chronoValueInMilliseconds = json_decode($chronoValue, true)['milliseconds'];
    $chronoStringValue = json_decode($chronoValue, true)['string'];
    $_SESSION['chronoValueInMilliseconds'] = $chronoValueInMilliseconds;
    $_SESSION['chronoStringValue'] = $chronoStringValue;

    $totalScore = 0;

    $categories = [
        'celebrity',
        'country',
        'city',
        'animal',
        'brand',
        'object',
        'colour'
    ];

    foreach ($categories as $category) {
        $scoreKey = 'S' . ($category);
        $value = $_SESSION[$category];
        echo "Checking $category: $value vs $randomLetter ($randomLetterLower, $randomLetterUpper)<br>"; //debuging
        if (substr($value, 0, 1) == $randomLetterLower || substr($value, 0, 1) == $randomLetterUpper) {
            echo "Match found for $category!<br>"; //debuging
            $_SESSION[$scoreKey] += 5;
            $totalScore += 5;
        }
    }

    if ($chronoValueInMilliseconds < 30000) {
        $totalScore *= 100;
    } elseif ($chronoValueInMilliseconds < 60000) {
        $totalScore *= 75;
    } elseif ($chronoValueInMilliseconds < 90000) {
        $totalScore *= 50;
    } elseif ($chronoValueInMilliseconds < 120000) {
        $totalScore*= 25;
    } elseif ($chronoValueInMilliseconds < 180000) {
        $totalScore *= 10;
    } elseif ($chronoValueInMilliseconds < 300000) {
        $totalScore *= 2;
    } elseif ($chronoValueInMilliseconds < 600000) {
        $totalScore*= 1.5;
    }

    $_SESSION['totalScore'] = $totalScore;

    header('Location: score.php');
    exit;
}
?>
