
    let startTime = 0,
    intervalId = null,
    isRunning = false;

    for (let i = 1; i <= 7; i++) {
        document.getElementById(`cell-${i}`).addEventListener("input", startChrono);
    }

    function startChrono() {
    if (!isRunning) {
    startTime = new Date().getTime();
    intervalId = setInterval(updateChrono, 100);
    isRunning = true;
}
}
    function updateChrono() {
    const currentTime = new Date().getTime();
    const elapsed = currentTime - startTime;
    const hours = Math.floor(elapsed / 3600000);
    const minutes = Math.floor((elapsed % 3600000) / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);
    const milliseconds = Math.floor((elapsed % 60000) % 100 );
    document.getElementById("chrono-display").innerText = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}:${pad(milliseconds)}`;
}
    // to add a 0 ex: 05 instead of 5
    function pad(number) {
        return (number < 10 ? "0" : "") + number;
    }

    function getChronoValue() {
        let chronoDisplay = document.getElementById("chrono-display");
        let chronoStringValue = chronoDisplay.innerText; // Get the chrono value from the display
        let [hours, minutes, seconds, milliseconds] = chronoStringValue.split(":"); // Split the chrono value into individual parts
        let totalMilliseconds = (
            parseInt(hours) * 3600000 + // Convert hours to milliseconds
            parseInt(minutes) * 60000 + // Convert minutes to milliseconds
            parseInt(seconds) * 1000 + // Convert seconds to milliseconds
            parseInt(milliseconds) // Add the milliseconds part
        );
        return {
            milliseconds: totalMilliseconds,
            string: chronoStringValue
        };
    }

    document.getElementById("myForm").addEventListener('submit', function(event) {
        event.preventDefault();
        let chronoValue = getChronoValue();
        let chronoInput = document.getElementById("chrono");
        chronoInput.value = JSON.stringify(chronoValue); // Send both values as a JSON object
        document.getElementById("myForm").submit(); // Submit the form
    });

    //Random Letter
    const alphabet = 'abcdefghijklmnopqrstuvwxyz'; //select a random letter in capital letter
    const randomLetter = alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    const uppercaseLetter = randomLetter.toUpperCase();
    document.getElementById('random-letter').textContent = uppercaseLetter;
    document.cookie = 'randomLetter=' + encodeURIComponent(randomLetter);

    //Click/unclick display text
    const toggleButton = document.querySelector('.toggle-button');
    const toggleContent = document.querySelector('.toggle-content');

    toggleButton.addEventListener('click', () => {
        toggleButton.classList.toggle('active');
        toggleContent.classList.toggle('active');
    });