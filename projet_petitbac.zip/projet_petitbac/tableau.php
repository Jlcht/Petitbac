<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Scattergories</title>
</head>
<body>
<h1 class="titre">Scattergories / Petit Bac</h1>
<br><br>

<link rel="stylesheet" type="text/css" href="tableau.css">

<button class="toggle-button">Rules</button>
<div class="toggle-content">
    <p>Write in the following cases word that starts with the letter indicated and matching with the categories</p>
    <p>Then click validate and you will earn a score : </p>
    <p>5 points for a correct answer</p>
    <p>0 pts for wrong/no answer</p>
    <p>The score will be multiplicated with the timer</p>
</div>
<h3 class="lettre">The letter is :</h3>

<h4 id="random-letter" class="lettrejeu"></h4>

<br><br>
<form id="myForm" action="tableau-back.php" method="post">
    <input type="hidden" id="chrono" name="chrono" value="">
    <div class="chrono" id="chrono-display" name="chrono">00:00:00:00</div>
<br><br>
    <table>
        <tr>
            <th>Celebrity</th>
            <th>Country</th>
            <th>City</th>
            <th>Animal</th>
        </tr>
        <tr>
            <td>
                <input type="text" id="cell-1" name="celebrity" value="" />
            </td>
            <td>
                <input type="text" id="cell-2" name="country" value="" />
            </td>
            <td>
                <input type="text" id="cell-3" name="city" value="" />
            </td>
            <td>
                <input type="text" id="cell-4" name="animal" value="" />
            </td>
        </tr>
    </table>
    <br><br>
    <table>
        <tr>
            <th>Object</th>
            <th>Colour</th>
            <th>A brand</th>
        </tr>
        <tr>
            <td>
                <input type="text" id="cell-5" name="brand" value="" />
            </td>
            <td>
                <input type="text" id="cell-6" name="object" value="" />
            </td>
            <td>
                <input type="text" id="cell-7" name="colour" value="" />
            </td>
        </tr>
    </table>
    <br><br>
    <input class="bouton1" type="submit" value="Validate" >
</form>
<script src="tableau.js"></script>
</body>
</html>



