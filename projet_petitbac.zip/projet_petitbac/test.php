<html lang="en">
<?php session_start();?>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php phpinfo(); ?>
<?php echo htmlspecialchars($_SESSION['celebrity']); ?>
</body>
</html>
